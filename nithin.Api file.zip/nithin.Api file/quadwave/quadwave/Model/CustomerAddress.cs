﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace quadwave.Model
{
    public class CustomerAddress
    {
        public int Id { set; get; }

        public int CustomerId { set; get; }

        public string City { set; get; }

        public string StreetAddress { set; get; }

        public string Country { set; get; }

        public string Phone { set; get; }

        public Customer Customers { set; get; }
    }
}
