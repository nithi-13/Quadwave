﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using quadwave.Dto;
using quadwave.Model;


namespace quadwave.Profiles
{
    public class CustomerProfiles : Profile
    {
        public CustomerProfiles()
        {
            CreateMap<Customer, CusReadDto> ();
            CreateMap<CusCreateDto, Customer>();
            CreateMap<CusUpdateDto, Customer>();
            CreateMap<CusDeleteDto, Customer>();
           CreateMap<CustomerAddress, AddressRdDto>();
        }
    }
}

