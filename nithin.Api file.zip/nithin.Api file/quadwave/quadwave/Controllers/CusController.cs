﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using quadwave.Data;
using quadwave.Dto;
using quadwave.Model;

namespace quadwave.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CusController : ControllerBase
    {
        private readonly ICustomerInfo _info;
        private readonly IMapper _mapper;

        //  private readonly ICustomerInfo _info;
        //  private readonly IMapper _mapper;

        public CusController(ICustomerInfo info, IMapper mapper)
        {
            _info = info;
            _mapper = mapper;

        }
        [HttpGet("{Id}")]

        public ActionResult<CusReadDto> GetCustomerById(int Id)
        {
            var cust = _info.GetCustomer(Id);
            return Ok(_mapper.Map<CusReadDto>(cust));
        }


        [HttpGet]

        public ActionResult<IEnumerable<CusReadDto>> GetCustomer()
        {
            var customer = _info.GetCustomers();
            return Ok(_mapper.Map<IEnumerable<CusReadDto>>(customer));

        }
        [HttpPut("{Id}")]

        public ActionResult UpdateCustomer(CusUpdateDto customerUpdateDto, int id)
        {
            var empInDb = _info.GetCustomer(id);
            if (empInDb != null)
            {
                _mapper.Map(customerUpdateDto, empInDb);
                _info.UpdateCustomer(empInDb);
                return Ok();
            }
            else
            {
                return NotFound();
            }
        }
        [HttpDelete("{Id}")]

        public ActionResult DeleteCust(CusDeleteDto customerDeleteDto, int Id)
        {
            var empInDb = _info.GetCustomer(Id);
            if (empInDb != null)
            {
                _mapper.Map(customerDeleteDto, empInDb);
                _info.DeleteCustomer(empInDb);
                return Ok();
            }

            return NotFound();
        }
        [HttpPost]

        public ActionResult<CusReadDto> Createcustomer(CusCreateDto customerCreateDto)
        {
            if (customerCreateDto != null)
            {

                var newCust = _mapper.Map<Customer>(customerCreateDto);
                _info.CreateCustomer(newCust);
                object CustomerCreateDto = null;
                return Ok(CustomerCreateDto);
            }
            else
            {
                return NotFound();
            }
        }
    }
}
