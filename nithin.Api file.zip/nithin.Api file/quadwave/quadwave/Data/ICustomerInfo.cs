﻿using quadwave.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace quadwave.Data
{
   public interface ICustomerInfo
    {
        public Customer GetCustomer(int id);

        public List<Customer> GetCustomers();

       public List<CustomerAddress> GetAddress();

        public Customer CreateCustomer(Customer c);

        public void UpdateCustomer(Customer c);

        public void DeleteCustomer(Customer c);


        //address
        public List<CustomerAddress> GetCustomerAddress();

    }
}
