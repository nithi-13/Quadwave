import { Component, OnInit } from "@angular/core";
import { Employee } from "./Customer.Model";
import { HttpClient } from "@angular/common/http";
import { ToastrService } from 'ngx-toastr';
import { EmployeeService } from "./CustomerService";
import { NgForm } from "@angular/forms";
import { Server } from "tls";

@Component({
  selector: 'app-root',
  templateUrl: './Employee.View.html',
  styles:[]
})

export class CustomerComponent implements OnInit {

  constructor(public service: CustomerService,
    private toastr: ToastrService) { }

  ngOnInit()
  {
    this.service.refreshList();
  }

  onSubmit(form: NgForm) {
    if (this.service.formData.Id== 0)
      this.insertRecord(form);
    else
      this.updateRecord(form);
  }
  Delete()
  {
  }
  insertRecord(form: NgForm) {
    this.service.CustomerDetail().subscribe(
      res => {
        this.resetForm(form);
        this.service.refreshList();
        this.toastr.success('Submitted successfully', 'Employee Register')
      },
      err => { console.log(err); }
    );
  }

  updateRecord(form: NgForm) {
    this.service.putCustomerDetail().subscribe(
      res => {
        this.resetForm(form);
        this.service.refreshList();
        this.toastr.info('Updated successfully', 'Employee Update')
      },
      err => { console.log(err); }
    );
  }
  deleteRecord(form: NgForm) {
    this.service.deleteCustomerDetail(form.controls["Id"].value);
  }


  resetForm(form: NgForm) {
    form.form.reset();
    this.service.formData = new Customer();
  }

}




