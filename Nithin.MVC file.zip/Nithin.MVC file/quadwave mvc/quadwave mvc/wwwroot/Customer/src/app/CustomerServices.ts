import { Injectable } from '@angular/core';
import { Employee } from './Customer.Module'
import { HttpClient } from "@angular/common/http";
import { Customer } from './Customer.cs/Customer Module';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(private http: HttpClient) { }


  readonly baseURL = 'http://localhost:5000/api/employees'
  formData: Customer = new Customer();
  list: Array<Customer> = new Array<Customer>();


  postCustomerDetail() {
    return this.http.post(this.baseURL, this.formData);
  }
  putCustomerDetail() {
    return this.http.put(`${this.baseURL}/${this.formData.Id}`, this.formData);
  }

  deleteCustomerDetail(id: number) {
    return this.http.delete(`${this.baseURL}/${id}`);
  }

  refreshList() {
    this.http.get(this.baseURL)
      .toPromise()
      .then(res => this.list = res as Employee[]);
    
  }


}

