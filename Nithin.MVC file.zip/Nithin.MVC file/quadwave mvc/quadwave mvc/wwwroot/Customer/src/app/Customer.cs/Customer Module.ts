export class Customer
{
    Id:number=0;
    Name:string="";
    Department:String="";
    Gender:string="";
}