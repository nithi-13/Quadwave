using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerApiMVC.Models
{
   static public class Customer
    {
        public static int Id { set; get; }
        public static string Name { set; get; }
        public static string Department { set; get; }
        public static string Gender { set; get; }
    }
}
